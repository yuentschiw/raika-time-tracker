// Raika Time Tracker - Background Service Worker v2
// 架构：所有状态存 chrome.storage.local，不依赖内存，兼容 SW 随时重启

const JSONBIN_KEY = "$2a$10$ZprY/cMDxkU1VHSX5dEiJ.bppSYR8JXoxx2smTlJwPjOvtYdmh1qy";
const JSONBIN_BIN_ID = "69ddb7dc856a6821892f8a86";
const JSONBIN_URL = `https://api.jsonbin.io/v3/b/${JSONBIN_BIN_ID}`;
const FLUSH_INTERVAL_MINUTES = 5;
const MIN_DURATION_SECONDS = 5;
const IDLE_THRESHOLD_SECONDS = 120;

// ─── storage 读写 ─────────────────────────────────────────────

async function getState() {
  const data = await chrome.storage.local.get(["currentSession", "pendingRecords"]);
  return {
    currentSession: data.currentSession || null,   // {tabId, url, title, startMs, category, label}
    pendingRecords: data.pendingRecords || []
  };
}

async function setState(patch) {
  await chrome.storage.local.set(patch);
}

// ─── URL 分类 ─────────────────────────────────────────────────
// 核心原则：以 URL host+path 为分类主键，title 只作辅助展示
// 过滤规则：单次停留 < MIN_DURATION_SECONDS 的记录直接丢弃（见 endCurrentSession）

// 内部系统域名 → 分类规则表（host 关键词 → {category, label函数, key函数}）
const URL_RULES = [
  // RedDoc 文档
  { match: h => h.includes("xiaohongshu.com"), pathRe: /\/doc\/([a-f0-9]{32})/,
    category: "redoc",
    label: (u, title, m) => `REDoc: ${title || m[1].slice(0,8)}`,
    key:   (u, m) => `redoc:${m[1]}` },

  // RedDoc Sheet 表格
  { match: h => h.includes("xiaohongshu.com"), pathRe: /\/sheet\/([a-f0-9]{32})/,
    category: "redoc",
    label: (u, title, m) => `REDoc表格: ${title || m[1].slice(0,8)}`,
    key:   (u, m) => `sheet:${m[1]}` },

  // RedDoc Table 多维表格
  { match: h => h.includes("xiaohongshu.com"), pathRe: /\/table\/([a-f0-9]{32})/,
    category: "redoc",
    label: (u, title, m) => `多维表格: ${title || m[1].slice(0,8)}`,
    key:   (u, m) => `table:${m[1]}` },

  // Hi IM（hiredcity / 内部 im 域名）
  { match: h => h.includes("hiredcity.com") || (h.includes("xiaohongshu.com") && false),
    category: "hi-im",
    label: (u, title) => `Hi: ${title || "消息"}`,
    key:   (u) => `hi:${u.hostname}${u.pathname.split("/").slice(0,3).join("/")}` },

  // RedBI 看板/图表
  { match: h => h.includes("redbi.devops.xiaohongshu.com"),
    category: "redbi",
    label: (u, title) => {
      const params = u.searchParams;
      const did = params.get("dashboardId") || "";
      const cid = params.get("chartId") || "";
      if (cid) return `RedBI图表: ${title || cid}`;
      if (did) return `RedBI看板: ${title || did}`;
      return `RedBI: ${title || u.pathname}`;
    },
    key: (u) => {
      const params = u.searchParams;
      const cid = params.get("chartId");
      const did = params.get("dashboardId");
      return cid ? `redbi:chart:${cid}` : did ? `redbi:dash:${did}` : `redbi:${u.pathname}`;
    }},

  // PingCode 工作项
  { match: h => h.includes("pingcode.com"),
    category: "pingcode",
    label: (u, title) => `PingCode: ${title || u.pathname.split("/").filter(Boolean)[0] || "工作项"}`,
    key:   (u) => `pingcode:${u.hostname}${u.pathname.split("/").slice(0,4).join("/")}` },

  // 云效/Codeup
  { match: h => h.includes("yunxiao.com") || h.includes("codeup.aliyun.com"),
    category: "yunxiao",
    label: (u, title) => `云效: ${title || u.pathname}`,
    key:   (u) => `yunxiao:${u.hostname}${u.pathname.split("/").slice(0,4).join("/")}` },

  // Omni 内网静态托管（自己发布的报告）
  { match: h => h.includes("omni.sit.xiaohongshu.com") || h.includes("omni.xiaohongshu.com"),
    category: "omni-report",
    label: (u, title) => `报告: ${u.pathname.split("/").filter(Boolean)[0] || title || "Omni"}`,
    key:   (u) => `omni:${u.pathname.split("/").filter(Boolean)[0] || u.pathname}` },

  // APM / 内部监控
  { match: h => h.includes("tracker.devops.xiaohongshu.com") || h.includes("apm"),
    category: "apm",
    label: (u, title) => `APM: ${title || u.pathname}`,
    key:   (u) => `apm:${u.hostname}${u.pathname}` },

  // ClawHub skill 平台
  { match: h => h.includes("skills.devops.xiaohongshu.com"),
    category: "clawhub",
    label: (u, title) => `ClawHub: ${u.searchParams.get("skill") || title || "skills"}`,
    key:   (u) => `clawhub:${u.searchParams.get("skill") || u.pathname}` },

  // 通用 xiaohongshu.com 内网（按 host+path前2段 聚合，避免 title 污染）
  { match: h => h.includes("xiaohongshu.com") || h.includes("xhscdn.com"),
    category: "xhs-internal",
    label: (u, title) => {
      // 用 host 子域作为系统名，比 title 更稳定
      const sub = u.hostname.replace(".xiaohongshu.com","").replace(".xhscdn.com","");
      const seg = u.pathname.split("/").filter(Boolean)[0] || "";
      const sysName = sub === "docs" ? "REDoc" :
                      sub.includes("redbi") ? "RedBI" :
                      sub.includes("tracker") ? "APM" :
                      sub.includes("skills") ? "ClawHub" :
                      sub || "内部系统";
      return `${sysName}${seg ? "/" + seg : ""}`;
    },
    key: (u) => {
      const sub = u.hostname.split(".")[0];
      const segs = u.pathname.split("/").filter(Boolean).slice(0,2).join("/");
      return `xhs:${sub}:${segs}`;
    }},

  // GitHub
  { match: h => h.includes("github.com"),
    category: "github",
    label: (u, title) => {
      const parts = u.pathname.split("/").filter(Boolean);
      return `GitHub: ${parts.slice(0,2).join("/") || title || ""}`;
    },
    key: (u) => `gh:${u.pathname.split("/").filter(Boolean).slice(0,2).join("/")}` },
];

function classifyUrl(url, title) {
  if (!url) return { category: "unknown", label: "未知" };
  try {
    const u = new URL(url);
    const host = u.hostname;
    if (["chrome:", "chrome-extension:", "about:", "edge:"].includes(u.protocol)) return null;

    for (const rule of URL_RULES) {
      if (!rule.match(host)) continue;
      // 有 pathRe 则需匹配路径
      if (rule.pathRe) {
        const m = u.pathname.match(rule.pathRe);
        if (!m) continue;
        return {
          category: rule.category,
          label: rule.label(u, title, m),
          key: rule.key(u, m),
        };
      }
      return {
        category: rule.category,
        label: rule.label(u, title),
        key: rule.key(u),
      };
    }

    // fallback：外部网站用 host 聚合，不用 title
    return {
      category: "web",
      label: host.replace(/^www\./, ""),
      key: `web:${host}`,
    };
  } catch {
    return { category: "web", label: url.slice(0, 60), key: `web:${url.slice(0,40)}` };
  }
}

// ─── 结束当前 session，存为 pending record ────────────────────

async function endCurrentSession(reason) {
  const { currentSession, pendingRecords } = await getState();
  if (!currentSession) return;

  const durationSeconds = Math.floor((Date.now() - currentSession.startMs) / 1000);
  if (durationSeconds >= MIN_DURATION_SECONDS) {
    const record = {
      timestamp: new Date().toISOString(),
      url: currentSession.url,
      title: currentSession.title,
      durationSeconds,
      category: currentSession.category,
      label: currentSession.label,
      key: currentSession.key || currentSession.label,
      reason
    };
    pendingRecords.push(record);
    console.log(`[TimeTracker] +record: ${record.label} ${durationSeconds}s`);
    await setState({ currentSession: null, pendingRecords });
  } else {
    await setState({ currentSession: null });
  }
}

// ─── 开始新 session ───────────────────────────────────────────

async function startSession(tabId, url, title) {
  const classified = classifyUrl(url, title);
  if (!classified) return; // 过滤 chrome:// 等

  await setState({
    currentSession: {
      tabId,
      url,
      title,
      startMs: Date.now(),
      category: classified.category,
      label: classified.label,
      key: classified.key || classified.label
    }
  });
  console.log(`[TimeTracker] start: ${classified.label}`);
}

// ─── Tab 事件 ─────────────────────────────────────────────────

chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  await endCurrentSession("tab-switch");
  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab.url) await startSession(tabId, tab.url, tab.title);
  } catch (e) {
    console.warn("[TimeTracker] onActivated error:", e.message);
  }
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete") return;
  const { currentSession } = await getState();
  if (currentSession && currentSession.tabId === tabId && changeInfo.url && changeInfo.url !== currentSession.url) {
    await endCurrentSession("navigation");
    await startSession(tabId, tab.url, tab.title);
  }
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  const { currentSession } = await getState();
  if (currentSession && currentSession.tabId === tabId) {
    await endCurrentSession("tab-closed");
  }
});

chrome.windows.onFocusChanged.addListener(async (windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    // 窗口失焦：结束计时（记录当前，等重新获焦再开始）
    await endCurrentSession("window-blur");
  } else {
    // 窗口获焦：找当前活跃 tab 开始计时
    try {
      const [tab] = await chrome.tabs.query({ active: true, windowId });
      if (tab && tab.url) await startSession(tab.id, tab.url, tab.title);
    } catch (e) {}
  }
});

// ─── Idle 检测 ────────────────────────────────────────────────

chrome.idle.setDetectionInterval(IDLE_THRESHOLD_SECONDS);
chrome.idle.onStateChanged.addListener(async (state) => {
  if (state === "idle" || state === "locked") {
    await endCurrentSession("idle");
  } else if (state === "active") {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.url) await startSession(tab.id, tab.url, tab.title);
    } catch (e) {}
  }
});

// ─── 定时 flush ───────────────────────────────────────────────

chrome.alarms.create("flush", { periodInMinutes: FLUSH_INTERVAL_MINUTES });

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== "flush" && alarm.name !== "flush-now") return;
  console.log("[TimeTracker] Alarm:", alarm.name);

  // 先快照当前 session（不结束，只追加一条 snapshot 记录）
  const { currentSession, pendingRecords } = await getState();
  if (currentSession) {
    const elapsed = Math.floor((Date.now() - currentSession.startMs) / 1000);
    if (elapsed >= MIN_DURATION_SECONDS) {
      pendingRecords.push({
        timestamp: new Date().toISOString(),
        url: currentSession.url,
        title: currentSession.title,
        durationSeconds: elapsed,
        category: currentSession.category,
        label: currentSession.label,
        key: currentSession.key || currentSession.label,
        reason: "snapshot"
      });
      // 重置 session 起点
      await setState({
        currentSession: { ...currentSession, startMs: Date.now() },
        pendingRecords
      });
    }
  }

  await flush();
});

// ─── Flush 到 JSONBin ─────────────────────────────────────────

// 压缩单条 record，去掉长 URL，只保留分析必需字段
function compactRecord(r) {
  return {
    ts: r.timestamp,          // 缩短字段名
    d:  r.durationSeconds,
    c:  r.category,
    k:  r.key || r.label,     // 用 key 代替完整 URL
    lb: (r.label || "").slice(0, 60),  // label 截断60字
    rz: r.reason ? r.reason[0] : "?"  // reason 只存首字母: s=snapshot, t=tab-switch 等
  };
}

// 还原 compact record 为分析脚本需要的格式
// (分析脚本也需要同步更新，见 analyze_time.py)

// 按 key+day 预聚合：同一天同一个 key 的记录合并成一条，大幅减少条数
function preAggregate(records) {
  const map = {};
  for (const r of records) {
    const day = (r.ts || r.timestamp || "").slice(0, 10);
    const key = `${day}||${r.k || r.key || r.lb || r.label}`;
    if (!map[key]) {
      map[key] = { ...r, d: 0, rz: "agg" };
    }
    map[key].d += (r.d || r.durationSeconds || 0);
    // 保留最新 label
    if (r.lb || r.label) map[key].lb = r.lb || (r.label || "").slice(0, 60);
  }
  return Object.values(map);
}

async function flush() {
  const { pendingRecords } = await getState();
  if (pendingRecords.length === 0) {
    console.log("[TimeTracker] Nothing to flush");
    return;
  }

  console.log(`[TimeTracker] Flushing ${pendingRecords.length} records...`);

  try {
    // 读取现有数据
    const getResp = await fetch(JSONBIN_URL + "/latest", {
      headers: { "X-Master-Key": JSONBIN_KEY }
    });
    const getJson = await getResp.json();
    const existing = getJson.record?.records || [];

    // 只保留7天（free plan 100kb 限制，7天够日报用）
    const cutoff = Date.now() - 7 * 24 * 3600 * 1000;

    // 合并：现有 + 新增，统一 compact 格式
    const compacted = [
      ...existing.map(r => r.ts ? r : compactRecord(r)),   // 已经是 compact 的不重复压缩
      ...pendingRecords.map(compactRecord)
    ].filter(r => new Date(r.ts || r.timestamp || 0).getTime() > cutoff);

    // 预聚合降低条数
    const aggregated = preAggregate(compacted);

    const body = JSON.stringify({ records: aggregated, lastUpdated: new Date().toISOString() });
    console.log(`[TimeTracker] Payload size: ${(body.length/1024).toFixed(1)}KB, ${aggregated.length} records`);

    const putResp = await fetch(JSONBIN_URL, {
      method: "PUT",
      headers: { "Content-Type": "application/json", "X-Master-Key": JSONBIN_KEY },
      body
    });

    if (putResp.ok) {
      console.log(`[TimeTracker] ✅ Flushed. Now ${aggregated.length} aggregated records`);
      await setState({ pendingRecords: [] });
    } else {
      const errText = await putResp.text();
      console.error("[TimeTracker] PUT failed:", errText);
      // 如果还是超限，强制截断只保3天
      if (errText.includes("100kb")) {
        const cutoff3d = Date.now() - 3 * 24 * 3600 * 1000;
        const trimmed = aggregated.filter(r => new Date(r.ts || 0).getTime() > cutoff3d);
        const body2 = JSON.stringify({ records: trimmed, lastUpdated: new Date().toISOString() });
        console.log(`[TimeTracker] Retrying with 3-day trim: ${(body2.length/1024).toFixed(1)}KB`);
        const r2 = await fetch(JSONBIN_URL, {
          method: "PUT",
          headers: { "Content-Type": "application/json", "X-Master-Key": JSONBIN_KEY },
          body: body2
        });
        if (r2.ok) {
          console.log("[TimeTracker] ✅ Retry succeeded");
          await setState({ pendingRecords: [] });
        }
      }
    }
  } catch (e) {
    console.error("[TimeTracker] Flush error:", e);
  }
}

// ─── Popup 消息 ───────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "PING") {
    // 心跳：SW 保持活跃，顺便检查是否需要快照
    getState().then(async ({ currentSession, pendingRecords }) => {
      if (currentSession) {
        const elapsed = Math.floor((Date.now() - currentSession.startMs) / 1000);
        // 每5分钟做一次快照
        if (elapsed >= 300) {
          pendingRecords.push({
            timestamp: new Date().toISOString(),
            url: currentSession.url,
            title: currentSession.title,
            durationSeconds: elapsed,
            category: currentSession.category,
            label: currentSession.label,
            key: currentSession.key || currentSession.label,
            reason: "ping-snapshot"
          });
          await setState({
            currentSession: { ...currentSession, startMs: Date.now() },
            pendingRecords
          });
          console.log(`[TimeTracker] ping-snapshot: ${currentSession.label} ${elapsed}s`);
          // 积累超过10条就 flush
          if (pendingRecords.length >= 10) await flush();
        }
      }
      sendResponse({ ok: true, elapsed: currentSession ? Math.floor((Date.now() - currentSession.startMs) / 1000) : 0 });
    });
    return true;
  }

  if (msg.type === "GET_STATUS") {
    getState().then(({ currentSession, pendingRecords }) => {
      const elapsed = currentSession
        ? Math.floor((Date.now() - currentSession.startMs) / 1000)
        : 0;

      // 今日统计
      const today = new Date().toISOString().split("T")[0];
      const todayMap = {};
      for (const r of pendingRecords.filter(r => r.timestamp.startsWith(today))) {
        const k = r.label || r.url;
        todayMap[k] = (todayMap[k] || 0) + r.durationSeconds;
      }
      const todayStats = Object.entries(todayMap)
        .map(([label, totalSeconds]) => ({ label, totalSeconds }))
        .sort((a, b) => b.totalSeconds - a.totalSeconds);

      sendResponse({
        url: currentSession?.url,
        title: currentSession?.title,
        category: currentSession?.category,
        label: currentSession?.label,
        elapsedSeconds: elapsed,
        pendingCount: pendingRecords.length,
        todayStats
      });
    });
    return true;
  }

  if (msg.type === "FORCE_FLUSH") {
    flush().then(() => sendResponse({ ok: true }));
    return true;
  }
});

// ─── 启动 ─────────────────────────────────────────────────────

async function init() {
  console.log("[TimeTracker] Service Worker started");
  // 找当前活跃 tab
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url) await startSession(tab.id, tab.url, tab.title);
  } catch (e) {}
}

chrome.runtime.onInstalled.addListener(init);
chrome.runtime.onStartup.addListener(init);
init(); // SW 每次唤醒都执行
